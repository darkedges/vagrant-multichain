var Client = require('bitcore-wallet-client');


var fs = require('fs');
var BWS_INSTANCE_URL = 'http://192.168.50.201:3232/bws/api'

var client = new Client({
  baseUrl: BWS_INSTANCE_URL,
  verbose: false,
});

client.import(fs.readFileSync('tomas.dat'));
client.openWallet(function(err, isComplete) {
	if (err) throw err;
        console.log(isComplete);
});

