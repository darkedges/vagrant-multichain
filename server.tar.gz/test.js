var bitcoin = require('bitcoin');

var client = new bitcoin.Client({
  host: 'localhost',
  port: 9238,
  user: 'multichainrpc',
  pass: 'Fmot4U4NdPrUZmSMdMZAHfiqDrFoGDEYz3vkGQn9rTEr',
  timeout: 30000
});

var address = '2N9o6Jqh2qbeUBCv1HDJi6dYXWFdhgqsfD6';


client.listUnspent(6,9999,[address], function(err, balance, resHeaders) {
  if (err) return console.log(err);
  console.log('Balance:', balance);
});
