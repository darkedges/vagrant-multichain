var bodyParser = require("body-parser");
var app        = require('express')();
var server     = require('http').createServer(app);
var io         = require('socket.io')(server);
var middleware = require('socketio-wildcard')();
var bitcoin    = require('bitcoin');


io.on('connection', function(socket) {
  console.log(socket);
  socket.on('*', function(packet){
	console.log(packet)
  });
});

var client = new bitcoin.Client({
  host: 'localhost',
  port: 9238,
  user: 'multichainrpc',
  pass: 'Fmot4U4NdPrUZmSMdMZAHfiqDrFoGDEYz3vkGQn9rTEr',
  timeout: 30000
});



app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/api/addrs/utxo', function(req, res){
  console.log(req);
  client.listUnspent(6,9999,[req.body.addrs], function(err, balance, resHeaders) {
  	if (err) return console.log(err);
  	console.log('Balance:', balance);
  });

});


server.listen(3000);
